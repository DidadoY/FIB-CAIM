"""
.. module:: SearchIndexWeight

SearchIndex
*************

:Description: SearchIndexWeight

    Performs a AND query for a list of words (--query) in the documents of an index (--index)
    You can use word^number to change the importance of a word in the match

    --nhits changes the number of documents to retrieve

:Authors: bejar
    

:Version: 

:Created on: 04/07/2017 10:56 

"""

from elasticsearch import Elasticsearch
from elasticsearch.exceptions import NotFoundError

import argparse

import numpy as np
import operator
from elasticsearch.client import CatClient
from elasticsearch_dsl import Search
from elasticsearch_dsl.query import Q

__author__ = 'bejar'


def search_file_by_path(client, index, path):
    """
    Search for a file using its path

    :param path:
    :return:
    """
    s = Search(using=client, index=index)
    q = Q('match', path=path)  # exact search in the path field
    s = s.query(q)
    result = s.execute()

    lfiles = [r for r in result]
    if len(lfiles) == 0:
        raise NameError(f'File [{path}] not found')
    else:
        return lfiles[0].meta.id


def document_term_vector(client, index, id):
    """
    Returns the term vector of a document and its statistics a two sorted list of pairs (word, count)
    The first one is the frequency of the term in the document, the second one is the number of documents
    that contain the term

    :param client:
    :param index:
    :param id:
    :return:
    """
    termvector = client.termvectors(index=index, id=id, fields=['text'],
                                    positions=False, term_statistics=True)

    file_td = {}
    file_df = {}

    if 'text' in termvector['term_vectors']:
        for t in termvector['term_vectors']['text']['terms']:
            file_td[t] = termvector['term_vectors']['text']['terms'][t]['term_freq']
            file_df[t] = termvector['term_vectors']['text']['terms'][t]['doc_freq']
    return sorted(file_td.items()), sorted(file_df.items())


def toTFIDF(client, index, file_id):
    """
    Returns the term weights of a document

    :param file:
    :return:
    """

    # Get the frequency of the term in the document, and the number of documents
    # that contain the term
    file_tv, file_df = document_term_vector(client, index, file_id)

    max_freq = max([f for _, f in file_tv])

    dcount = doc_count(client, index)

    tfidfw = {}
    for (t, w),(_, df) in zip(file_tv, file_df):
        tf = w/max_freq
        idf = np.log2(dcount/df)
        tfidf = tf * idf
        tfidfw[t] = tfidf
        pass

    return normalize(tfidfw)

def print_term_weigth_vector(twv):
    """
    Prints the term vector and the correspondig weights
    :param twv:
    :return:
    """
    for tfidf in twv:
        print(tfidf)
    pass

modulo = lambda x : np.sqrt(np.sum(np.square(x)))

def normalize(tw):
	"""
	Normalizes the weights in t so that they form a unit-length vector
	It is assumed that not all weights are 0
	:param tw:
	:return:
	"""
	elementos = tw.items()
	weights =  [elem[1] for elem in elementos]
	finalMod = modulo(weights)
	
	normalized = {x[0] : tw.get(x[0])/finalMod for x in elementos}
	
	return normalized


def doc_count(client, index):
    """
    Returns the number of documents in an index

    :param client:
    :param index:
    :return:
    """
    return int(CatClient(client).count(index=[index], format='json')[0]['count'])

def query2list(query):
	query_list = []
	for q in query:
		word = q
		val = 1.0
		
		if '^' in q:
			word, val = q.split('^')
		query_list.append((word,float(val)))
		
	return query_list

def calc_tfidf(client, index, response,beta):

	k = len(response)
	pond = beta / k
	for r in response:  # only returns a specific number of results
		file_id = search_file_by_path(client, index, r.path)
		file_tw = toTFIDF(client, index, file_id)
		
		for word in file_tw:
			file_tw[word] *= pond

		print(f'ID= {r.meta.id} SCORE={r.meta.score}')
		print(f'PATH= {r.path}')
		print(f'TEXT: {r.text[:50]}')
		print('-----------------------------------------------------------------')
	return file_tw

def list2query(list):
	query = []
	for word, val in list:
		query.append(word+'^'+str(val))
	return query
if __name__ == '__main__':
	parser = argparse.ArgumentParser()
	parser.add_argument('--index', default=None, help='Index to search')
	parser.add_argument('--k', default=10, type=int, help='Number of hits to return')
	parser.add_argument('--alpha', default=1, type=float, help='Alpha parameter')
	parser.add_argument('--beta', default=1, type=float, help='Beta parameter')
	parser.add_argument('--nrounds', default=5, type=int, help='Number of iterations to converge')
	parser.add_argument('--R', default=5, type=int, help='Most Relevant words')
	parser.add_argument('--query', default=None, nargs=argparse.REMAINDER, help='List of words to search')

	args = parser.parse_args()

	index = args.index
	query = args.query
	print(query)
	k = args.k
	alpha = args.alpha
	beta = args.beta
	nrounds = args.nrounds
	R = args.R
	for n in range(nrounds):
		query_list= query2list(query)
		try:
			client = Elasticsearch(timeout=1000)
			s = Search(using=client, index=index)

			if query is not None:
				q = Q('query_string',query=query[0])
				for i in range(1, len(query)):
					q &= Q('query_string',query=query[i])

				s = s.query(q)
				response = s[0:k].execute()
				# Calculem la suma dels tfidf dels documents multiplicant per beta i dividint per K
				dict_query = calc_tfidf(client, index, response,beta)
				# Sumem a la query multiplicant per alpha
				for word, val in query_list:
					if word in dict_query:
						dict_query[word] += alpha*val
					else:
						dict_query[word] = alpha*val
				# Ordenem el diccionari i ho convertim tot en query
				query_sorted = sorted(dict_query.items(), key=operator.itemgetter(1), reverse=True)
				list_sorted = list(query_sorted)
				query = list2query(list_sorted[:R])
			else:
				print('No query parameters passed')

			print (f"{response.hits.total['value']} Documents \n\n")

		except NotFoundError:
			print(f'Index {index} does not exists')
		
		print(query)
	

